# نگاه جوان — Android 16 v1.2

نسخه تمرکز روی انتشار مستقیم در تلگرام، روبیکا و بله، بدون نیاز به وب‌سایت یا Vercel.

- Telegram: انتشار خودکار متن و تصویر با Bot API
- Rubika: انتشار خودکار متن و تصویر با Bot API
- Bale: انتشار خودکار متن و تصویر با Bot API
- WhatsApp Channel: آماده‌سازی متن و باز کردن Share به‌صورت دستی، چون API عمومی رسمی برای انتشار Channel در این نسخه در دسترس نیست.
- توکن‌ها با Android Keystore رمزگذاری و فقط روی گوشی ذخیره می‌شوند.

در Settings توکن و شناسه کانال هر سرویس را وارد کنید، ذخیره بزنید و سپس Test Connection را اجرا کنید.


## v1.4 changes
- WhatsApp share now includes news text + selected image.
- Encrypted portable backup/restore for news archive, channel IDs, and connector tokens.
- Backup encryption uses a user-provided password (AES-GCM + PBKDF2).
