# Negah Javan Android 16
Clean Android project for the Negah Javan newsroom app.
Target SDK: 36 (Android 16)
Minimum SDK: 26
Build: gradle :app:assembleDebug
