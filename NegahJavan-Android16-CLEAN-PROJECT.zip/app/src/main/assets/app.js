const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const PLATFORM_LABELS={telegram:'تلگرام',rubika:'روبیکا',bale:'بله',whatsapp:'واتس‌اپ'};
const seed=[
 {id:1,title:'درخشش دختران نونهال جیرفتی در مسابقات منطقه ۶',cat:'ورزشی',time:'۱۸ دقیقه قبل',state:'published',icon:'🥋',dest:['تلگرام','روبیکا','بله']},
 {id:2,title:'گزارش ویژه از پروژه‌های شهری جنوب کرمان',cat:'اجتماعی',time:'۴۲ دقیقه قبل',state:'published',icon:'🏙️',dest:['تلگرام','روبیکا']},
 {id:3,title:'جمع‌بندی مهم‌ترین خبرهای امشب نگاه جوان',cat:'خبر فوری',time:'امشب ۲۲:۰۰',state:'scheduled',icon:'⚡',dest:['تلگرام','روبیکا','بله']},
 {id:4,title:'گفت‌وگو با جوانان کارآفرین منطقه',cat:'اقتصادی',time:'پیش‌نویس',state:'draft',icon:'🎙️',dest:['بله']}
];
let news=JSON.parse(localStorage.getItem('nj_news')||'null')||seed;
let imagePayload=null;
let publishing=false;
const save=()=>localStorage.setItem('nj_news',JSON.stringify(news));
const toast=(msg,sub='')=>{const t=$('#toast');t.querySelector('b').textContent=msg;t.querySelector('small').textContent=sub;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3200)};
function nav(screen){$$('.screen').forEach(x=>x.classList.toggle('active',x.dataset.screen===screen));$$('.bottom-nav button[data-nav]').forEach(x=>x.classList.toggle('active',x.dataset.nav===screen));window.scrollTo({top:0,behavior:'smooth'});if(screen==='archive')renderArchive();if(screen==='queue')renderQueue();if(screen==='settings')loadNativeConfig();}
$$('[data-nav]').forEach(b=>b.onclick=()=>nav(b.dataset.nav));
function renderFeed(){const list=$('#feedList');list.innerHTML=news.slice(0,3).map(n=>`<article class="feed-item"><div class="thumb">${n.icon||'📰'}</div><div class="feed-content"><b>${escapeHtml(n.title)}</b><small>${escapeHtml(n.cat)} • ${escapeHtml(n.time)}</small><div class="dest-mini">${(n.dest||[]).map(d=>`<i>${escapeHtml(d)}</i>`).join('')}</div></div><span class="feed-status ${n.state==='scheduled'?'scheduled':''}">${n.state==='published'?'منتشر شد':n.state==='scheduled'?'زمان‌بندی':'پیش‌نویس'}</span></article>`).join('')}
function renderArchive(filter='all'){const q=($('#searchInput')?.value||'').trim();const items=news.filter(n=>(filter==='all'||n.state===filter)&&(!q||n.title.includes(q)||n.cat.includes(q)));$('#archiveList').innerHTML=items.map(n=>`<article class="archive-item"><div class="archive-top"><div class="thumb">${n.icon||'📰'}</div><div><b>${escapeHtml(n.title)}</b><small>${escapeHtml(n.cat)} • ${escapeHtml(n.time)}</small><div class="dest-mini">${(n.dest||[]).map(d=>`<i>${escapeHtml(d)}</i>`).join('')}</div></div><span class="feed-status ${n.state==='scheduled'?'scheduled':''}">${n.state==='published'?'منتشر':n.state==='scheduled'?'زمان‌بندی':'پیش‌نویس'}</span></div><div class="archive-actions"><span>شناسه #${String(n.id).slice(-6)}</span><button onclick="deleteNews(${n.id})">حذف</button></div></article>`).join('')||'<div style="text-align:center;color:#648073;padding:40px 0;font-size:11px">خبری پیدا نشد.</div>'}
window.deleteNews=id=>{news=news.filter(n=>n.id!==id);save();renderArchive(currentFilter);renderFeed();toast('خبر حذف شد','از آرشیو محلی برنامه')};
let currentFilter='all';$$('.filters button').forEach(b=>b.onclick=()=>{$$('.filters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');currentFilter=b.dataset.filter;renderArchive(currentFilter)});$('#searchInput').oninput=()=>renderArchive(currentFilter);
function renderQueue(){const q=news.filter(n=>n.state==='scheduled'||n.state==='draft');$('#queueList').innerHTML=q.map((n,i)=>`<article class="timeline-item"><b>${escapeHtml(n.title)}</b><small>${escapeHtml(n.cat)} • ${(n.dest||[]).join(' + ')}</small><div class="timeline-meta"><span>${n.state==='scheduled'?n.time:'منتظر تأیید سردبیر'}</span><b>${i===0?'بعدی':'در صف'}</b></div></article>`).join('')||'<div style="text-align:center;color:#648073;padding:40px 0;font-size:11px">صف انتشار خالی است.</div>'}
const comp=$('#composer');$$('[data-open-compose]').forEach(b=>b.onclick=()=>comp.classList.add('open'));$$('[data-close]').forEach(b=>b.onclick=()=>comp.classList.remove('open'));comp.onclick=e=>{if(e.target===comp)comp.classList.remove('open')};
$('#imageInput').onchange=e=>prepareImage(e.target.files[0]);
async function prepareImage(file){if(!file)return;if(file.size>12*1024*1024){toast('تصویر خیلی بزرگ است','حداکثر ۱۲ مگابایت انتخاب کن');return}try{const dataUrl=await compressImage(file);imagePayload={name:(file.name||'news.jpg').replace(/\.[^.]+$/,'.jpg'),type:'image/jpeg',dataBase64:dataUrl.split(',')[1]};const img=$('#imagePreview');img.src=dataUrl;img.style.display='block';$('#imageLabel').style.display='none';toast('تصویر آماده شد','برای تلگرام، روبیکا و بله همراه خبر ارسال می‌شود')}catch(e){toast('خواندن تصویر ناموفق بود',e.message||'دوباره تلاش کن')}}
function compressImage(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=()=>reject(new Error('فایل خوانده نشد'));r.onload=()=>{const im=new Image();im.onerror=()=>reject(new Error('تصویر معتبر نیست'));im.onload=()=>{const max=1600,ratio=Math.min(1,max/Math.max(im.width,im.height));const c=document.createElement('canvas');c.width=Math.round(im.width*ratio);c.height=Math.round(im.height*ratio);c.getContext('2d').drawImage(im,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.82))};im.src=r.result};r.readAsDataURL(file)})}
$('#toggleAll').onclick=()=>{const all=$$('.dest:not([disabled])');const set=all.some(x=>!x.checked);all.forEach(x=>x.checked=set);updatePublishButton()};
$$('.dest').forEach(x=>x.onchange=updatePublishButton);
function updatePublishButton(){const n=$$('.dest:checked').length;$('#publishBtn').innerHTML=`<span>⚡</span> انتشار در ${faNum(n)} مقصد`;}
$('#aiBtn').onclick=()=>{const t=$('#titleInput');if(!t.value.trim())t.value='تیتر پیشنهادی هوشمند برای خبر جدید';else if(!t.value.includes(' | نگاه جوان'))t.value=t.value+' | نگاه جوان';toast('تیتر بهینه شد','نسخه فعلی دستیار تحریریه')};
$('#draftBtn').onclick=()=>createLocal('draft');
$('#publishBtn').onclick=()=>publishNow();
function createLocal(state){const title=$('#titleInput').value.trim();if(!title){toast('تیتر خبر خالی است','ابتدا تیتر را وارد کن');return}const dest=getSelectedLabels();const item={id:Date.now(),title,cat:$('#categoryInput').value,time:state==='scheduled'?'زمان‌بندی‌شده':'پیش‌نویس',state,icon:'📰',dest,lead:$('#leadInput').value,body:$('#bodyInput').value};news.unshift(item);save();renderFeed();comp.classList.remove('open');resetComposer();toast('پیش‌نویس ذخیره شد',dest.join(' • '));}
function publishNow(){if(publishing)return;const title=$('#titleInput').value.trim();if(!title){toast('تیتر خبر خالی است','ابتدا تیتر را وارد کن');return}const destinations=$$('.dest:checked').map(x=>x.value);if(!destinations.length){toast('هیچ مقصدی انتخاب نشده','حداقل یک مقصد را انتخاب کن');return}if($('#timingInput').value==='schedule'){createLocal('scheduled');toast('زمان‌بندی محلی ثبت شد','انتشار زمان‌بندی‌شده در نسخه بعدی فعال می‌شود');return}if(!window.NegahAndroid){toast('پل ارتباطی اندروید پیدا نشد','برنامه را روی گوشی اجرا کن');return}const payload={title,lead:$('#leadInput').value.trim(),body:$('#bodyInput').value.trim(),category:$('#categoryInput').value,destinations,image:imagePayload};publishing=true;$('#publishBtn').classList.add('publish-busy');$('#publishBtn').innerHTML='<span>◌</span> در حال انتشار...';try{window.NegahAndroid.publish(JSON.stringify(payload));}catch(e){publishing=false;$('#publishBtn').classList.remove('publish-busy');updatePublishButton();toast('ارسال شروع نشد',e.message||'خطای برنامه')}}
function getSelectedLabels(){return $$('.dest:checked').map(x=>PLATFORM_LABELS[x.value]||x.value)}
function resetComposer(){$('#titleInput').value='';$('#leadInput').value='';$('#bodyInput').value='';$('#imageInput').value='';$('#imagePreview').style.display='none';$('#imageLabel').style.display='';imagePayload=null;updatePublishButton()}
function loadNativeConfig(){
 if(!window.NegahAndroid)return;
 try{
  const c=JSON.parse(window.NegahAndroid.getConfig()||'{}');
  $('#telegramChannelInput').value=c.telegramChannel||'';
  $('#rubikaChatInput').value=c.rubikaChat||'';
  $('#baleChannelInput').value=c.baleChannel||'';
  if(c.hasTelegramToken)$('#telegramTokenInput').placeholder='توکن ذخیره شده ••••••••';
  if(c.hasRubikaToken)$('#rubikaTokenInput').placeholder='توکن ذخیره شده ••••••••';
  if(c.hasBaleToken)$('#baleTokenInput').placeholder='توکن ذخیره شده ••••••••';
  setConnectorState('telegram',c.hasTelegramToken&&c.telegramChannel?'ذخیره شده':'تنظیم نشده',!!(c.hasTelegramToken&&c.telegramChannel));
  setConnectorState('rubika',c.hasRubikaToken&&c.rubikaChat?'ذخیره شده':'تنظیم نشده',!!(c.hasRubikaToken&&c.rubikaChat));
  setConnectorState('bale',c.hasBaleToken&&c.baleChannel?'ذخیره شده':'تنظیم نشده',!!(c.hasBaleToken&&c.baleChannel));
  setConnectorState('whatsapp','دستی',false);
 }catch(e){toast('خواندن تنظیمات ناموفق بود',e.message||'')}
}
$('#saveDirectBtn').onclick=()=>{
 if(!window.NegahAndroid)return toast('این تنظیم فقط داخل اپ فعال است');
 const cfg={
  telegramToken:$('#telegramTokenInput').value.trim(),
  telegramChannel:$('#telegramChannelInput').value.trim(),
  rubikaToken:$('#rubikaTokenInput').value.trim(),
  rubikaChat:$('#rubikaChatInput').value.trim(),
  baleToken:$('#baleTokenInput').value.trim(),
  baleChannel:$('#baleChannelInput').value.trim()
 };
 try{window.NegahAndroid.saveDirectConfig(JSON.stringify(cfg));}catch(e){toast('ذخیره ناموفق بود',e.message||'')}
};
function connectorPayload(c){
 if(c==='telegram')return {telegramToken:$('#telegramTokenInput').value.trim(),telegramChannel:$('#telegramChannelInput').value.trim()};
 if(c==='rubika')return {rubikaToken:$('#rubikaTokenInput').value.trim(),rubikaChat:$('#rubikaChatInput').value.trim()};
 if(c==='bale')return {baleToken:$('#baleTokenInput').value.trim(),baleChannel:$('#baleChannelInput').value.trim()};
 return {};
}

$('#backupExportBtn').onclick=()=>{
 if(!window.NegahAndroid)return toast('فقط داخل اپ قابل استفاده است');
 const password=$('#backupPasswordInput').value;
 if(password.length<6)return toast('رمز پشتیبان کوتاه است','حداقل ۶ کاراکتر وارد کن');
 try{window.NegahAndroid.exportBackup(JSON.stringify({password,news}));}
 catch(e){toast('ساخت پشتیبان شروع نشد',e.message||'خطای داخلی برنامه')}
};
$('#backupImportBtn').onclick=()=>{
 if(!window.NegahAndroid)return toast('فقط داخل اپ قابل استفاده است');
 const password=$('#backupPasswordInput').value;
 if(password.length<6)return toast('رمز پشتیبان را وارد کن','همان رمزی که موقع ساخت فایل استفاده کردی');
 try{window.NegahAndroid.importBackup(password);}
 catch(e){toast('بازیابی شروع نشد',e.message||'خطای داخلی برنامه')}
};
$('#rubikaDiscoverBtn').onclick=()=>{
 if(!window.NegahAndroid)return toast('فقط داخل اپ قابل استفاده است');
 const token=$('#rubikaTokenInput').value.trim();
 setConnectorState('rubika','در حال یافتن شناسه...',false);
 try{window.NegahAndroid.discoverRubikaChat(JSON.stringify({rubikaToken:token}));}
 catch(e){setConnectorState('rubika','خطا',false);toast('یافتن شناسه ناموفق بود',e.message||'خطای داخلی برنامه')}
};
$$('[data-test]').forEach(b=>b.onclick=()=>{
 const c=b.dataset.test;
 if(!window.NegahAndroid)return toast('فقط داخل اپ قابل تست است');
 setConnectorState(c,c==='whatsapp'?'در حال باز کردن...':'در حال ذخیره و تست...',false);
 try{
  if(c==='whatsapp')window.NegahAndroid.testConnector(c);
  else window.NegahAndroid.saveAndTestConnector(c,JSON.stringify(connectorPayload(c)));
 }catch(e){
  setConnectorState(c,'خطا',false);
  toast('تست اتصال ناموفق بود',e.message||'خطای داخلی برنامه');
 }
});
function setConnectorState(name,text,ok){const el=$(`.connector-status[data-status="${name}"]`);if(!el)return;el.textContent=text;el.classList.toggle('ok',ok);el.classList.toggle('setup',!ok)}
window.NJ={
 onConfigSaved:r=>{toast(r.ok?'اتصال‌ها ذخیره شدند':'ذخیره ناموفق',r.message||'');loadNativeConfig()},
 onRubikaDiscovered:r=>{
  if(r.ok&&r.chat_id){$('#rubikaChatInput').value=r.chat_id;setConnectorState('rubika','شناسه پیدا شد',true);toast('شناسه کانال روبیکا پیدا شد',r.chat_id+' — حالا تست اتصال را بزن');}
  else{setConnectorState('rubika','خطا',false);toast('شناسه کانال پیدا نشد',r.message||'در کانال /test بفرست و دوباره امتحان کن')}
 },
 onConnectorTest:r=>{const c=r.connector||r.name||'unknown';const manual=r.status==='manual';const ok=!!r.ok&&!manual;setConnectorState(c,manual?'دستی':ok?'متصل':'خطا',ok);toast(manual?'واتس‌اپ آماده است':ok?`${PLATFORM_LABELS[c]||c} متصل است`:`اتصال ${PLATFORM_LABELS[c]||c} ناموفق`,r.message||'')},
 onBackupExported:r=>{toast(r.ok?'پشتیبان ذخیره شد':'پشتیبان ذخیره نشد',r.message||'')},
 onBackupRestored:r=>{
  if(!r.ok){toast('بازیابی ناموفق بود',r.message||'');return}
  if(Array.isArray(r.news)){news=r.news;save();renderFeed();renderArchive();renderQueue()}
  loadNativeConfig();
  toast('پشتیبان بازیابی شد','خبرها و تنظیمات اتصال برگردانده شدند')
 },
 onPublishResult:r=>{
  publishing=false;$('#publishBtn').classList.remove('publish-busy');updatePublishButton();
  if(!r.ok){toast('انتشار ناموفق بود',r.message||'خطای اتصال');return}
  const results=r.results||{};
  const dest=Object.entries(results).filter(([,v])=>v&&v.ok).map(([k])=>PLATFORM_LABELS[k]||k);
  const manual=Object.entries(results).filter(([,v])=>v&&v.status==='manual').map(([k])=>PLATFORM_LABELS[k]||k);
  const failed=Object.entries(results).filter(([,v])=>v&&!v.ok&&v.status!=='manual').map(([k])=>PLATFORM_LABELS[k]||k);
  const item={id:Date.now(),title:$('#titleInput').value.trim(),cat:$('#categoryInput').value,time:'همین حالا',state:'published',icon:'📰',dest:[...dest,...manual.map(x=>x+' (دستی)')],lead:$('#leadInput').value,body:$('#bodyInput').value,remote:r};
  news.unshift(item);save();renderFeed();comp.classList.remove('open');resetComposer();
  let msg=dest.length?`موفق: ${dest.join(' • ')}`:'پاسخ دریافت شد';
  if(manual.length)msg+=` | دستی: ${manual.join(' • ')}`;
  if(failed.length)msg+=` | خطا: ${failed.join(' • ')}`;
  toast('فرآیند انتشار انجام شد',msg)
 }
};
$('#bellBtn').onclick=()=>toast('مرکز اعلان‌ها','نتیجه هر انتشار در همین بخش ثبت می‌شود');
const heights=[34,55,42,69,62,81,74];$('#bars').innerHTML=heights.map(h=>`<i class="bar" style="height:${h}%"></i>`).join('');
function escapeHtml(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function faNum(n){return String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d])}
renderFeed();renderArchive();renderQueue();updatePublishButton();setTimeout(loadNativeConfig,250);
