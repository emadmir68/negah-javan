package com.negahjavan.newsroom;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 301;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private SecureStore secureStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("negah_javan_secure_config", MODE_PRIVATE);
        secureStore = new SecureStore(prefs);

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new PublisherBridge(), "NegahAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    () -> {
                        if (webView != null && webView.canGoBack()) webView.goBack();
                        else finish();
                    }
            );
        }
    }

    public class PublisherBridge {
        @JavascriptInterface
        public String getConfig() {
            try {
                JSONObject o = new JSONObject();
                o.put("telegramChannel", prefs.getString("telegram_channel", ""));
                o.put("rubikaChat", prefs.getString("rubika_chat", ""));
                o.put("baleChannel", prefs.getString("bale_channel", ""));
                o.put("hasTelegramToken", !secureStore.get("telegram_token").isEmpty());
                o.put("hasRubikaToken", !secureStore.get("rubika_token").isEmpty());
                o.put("hasBaleToken", !secureStore.get("bale_token").isEmpty());
                o.put("mode", "direct");
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void saveDirectConfig(String payload) {
            try {
                JSONObject p = new JSONObject(payload == null ? "{}" : payload);
                SharedPreferences.Editor ed = prefs.edit();

                if (p.has("telegramChannel")) ed.putString("telegram_channel", clean(p.optString("telegramChannel")));
                if (p.has("rubikaChat")) ed.putString("rubika_chat", clean(p.optString("rubikaChat")));
                if (p.has("baleChannel")) ed.putString("bale_channel", clean(p.optString("baleChannel")));
                ed.apply();

                String telegramToken = clean(p.optString("telegramToken"));
                String rubikaToken = clean(p.optString("rubikaToken"));
                String baleToken = clean(p.optString("baleToken"));
                if (!telegramToken.isEmpty()) secureStore.put("telegram_token", telegramToken);
                if (!rubikaToken.isEmpty()) secureStore.put("rubika_token", rubikaToken);
                if (!baleToken.isEmpty()) secureStore.put("bale_token", baleToken);

                callback("onConfigSaved", jsonOk("تنظیمات اتصال ذخیره شد"));
            } catch (Exception e) {
                callback("onConfigSaved", jsonError(e.getMessage()));
            }
        }

        @JavascriptInterface
        public void testConnector(String connector) {
            executor.execute(() -> {
                String c = connector == null ? "" : connector.toLowerCase(Locale.ROOT);
                try {
                    JSONObject r;
                    if ("telegram".equals(c)) r = testTelegram();
                    else if ("rubika".equals(c)) r = testRubika();
                    else if ("bale".equals(c)) r = testBale();
                    else if ("whatsapp".equals(c)) {
                        r = new JSONObject();
                        r.put("ok", true);
                        r.put("connector", "whatsapp");
                        r.put("status", "manual");
                        r.put("message", "واتس‌اپ در حالت اشتراک‌گذاری دستی باز می‌شود");
                    } else throw new Exception("اتصال ناشناخته است");
                    callback("onConnectorTest", r.toString());
                } catch (Exception e) {
                    try {
                        JSONObject r = new JSONObject();
                        r.put("ok", false);
                        r.put("connector", c);
                        r.put("message", e.getMessage());
                        callback("onConnectorTest", r.toString());
                    } catch (Exception ignored) {
                        callback("onConnectorTest", jsonError(e.getMessage()));
                    }
                }
            });
        }

        @JavascriptInterface
        public void publish(String payload) {
            executor.execute(() -> {
                try {
                    JSONObject p = new JSONObject(payload == null ? "{}" : payload);
                    String title = clean(p.optString("title"));
                    String lead = clean(p.optString("lead"));
                    String body = clean(p.optString("body"));
                    if (title.isEmpty()) throw new Exception("تیتر خبر خالی است");

                    JSONArray destinations = p.optJSONArray("destinations");
                    if (destinations == null || destinations.length() == 0) throw new Exception("مقصدی انتخاب نشده است");

                    byte[] imageBytes = null;
                    String imageName = "news.jpg";
                    String imageType = "image/jpeg";
                    JSONObject image = p.optJSONObject("image");
                    if (image != null && !clean(image.optString("dataBase64")).isEmpty()) {
                        imageBytes = Base64.decode(image.optString("dataBase64"), Base64.DEFAULT);
                        if (imageBytes.length > 10 * 1024 * 1024) throw new Exception("حجم تصویر بیشتر از ۱۰ مگابایت است");
                        if (!clean(image.optString("name")).isEmpty()) imageName = image.optString("name");
                        if (!clean(image.optString("type")).isEmpty()) imageType = image.optString("type");
                    }

                    JSONObject results = new JSONObject();
                    int automaticCount = 0;
                    int successCount = 0;
                    boolean wantsWhatsApp = false;

                    for (int i = 0; i < destinations.length(); i++) {
                        String d = destinations.optString(i, "").toLowerCase(Locale.ROOT);
                        if (d.isEmpty()) continue;
                        try {
                            JSONObject r;
                            if ("telegram".equals(d)) {
                                automaticCount++;
                                r = publishTelegram(title, lead, body, imageBytes, imageName, imageType);
                                successCount++;
                            } else if ("rubika".equals(d)) {
                                automaticCount++;
                                r = publishRubika(title, lead, body, imageBytes, imageName, imageType);
                                successCount++;
                            } else if ("bale".equals(d)) {
                                automaticCount++;
                                r = publishBale(title, lead, body, imageBytes, imageName, imageType);
                                successCount++;
                            } else if ("whatsapp".equals(d)) {
                                wantsWhatsApp = true;
                                r = new JSONObject();
                                r.put("ok", false);
                                r.put("status", "manual");
                                r.put("message", "متن خبر برای واتس‌اپ آماده شد");
                            } else {
                                r = new JSONObject();
                                r.put("ok", false);
                                r.put("message", "مقصد ناشناخته");
                            }
                            results.put(d, r);
                        } catch (Exception e) {
                            JSONObject r = new JSONObject();
                            r.put("ok", false);
                            r.put("message", e.getMessage());
                            results.put(d, r);
                        }
                    }

                    if (wantsWhatsApp) shareToWhatsApp(formatNews(title, lead, body));

                    JSONObject out = new JSONObject();
                    boolean ok = automaticCount == 0 || successCount > 0 || wantsWhatsApp;
                    out.put("ok", ok);
                    out.put("message", ok ? "فرآیند انتشار انجام شد" : "هیچ مقصد خودکاری موفق نبود");
                    out.put("results", results);
                    callback("onPublishResult", out.toString());
                } catch (Exception e) {
                    callback("onPublishResult", jsonError(e.getMessage()));
                }
            });
        }
    }

    private JSONObject testTelegram() throws Exception {
        String token = secureStore.get("telegram_token");
        String channel = clean(prefs.getString("telegram_channel", ""));
        if (token.isEmpty() || channel.isEmpty()) throw new Exception("توکن و شناسه کانال تلگرام را وارد کنید");
        JSONObject d = httpJson("GET", "https://api.telegram.org/bot" + token + "/getMe", null);
        ensureOk(d, "Telegram");
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("connector", "telegram");
        out.put("message", "بات تلگرام پاسخ داد");
        return out;
    }

    private JSONObject testBale() throws Exception {
        String token = secureStore.get("bale_token");
        String channel = clean(prefs.getString("bale_channel", ""));
        if (token.isEmpty() || channel.isEmpty()) throw new Exception("توکن و شناسه کانال بله را وارد کنید");
        JSONObject d = httpJson("GET", "https://tapi.bale.ai/bot" + token + "/getMe", null);
        ensureOk(d, "Bale");
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("connector", "bale");
        out.put("message", "بات بله پاسخ داد");
        return out;
    }

    private JSONObject testRubika() throws Exception {
        String token = secureStore.get("rubika_token");
        String chat = clean(prefs.getString("rubika_chat", ""));
        if (token.isEmpty() || chat.isEmpty()) throw new Exception("توکن و شناسه کانال روبیکا را وارد کنید");
        JSONObject d = rubikaCall(token, "getMe", new JSONObject());
        ensureRubikaOk(d);
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("connector", "rubika");
        out.put("message", "بات روبیکا پاسخ داد");
        return out;
    }

    private JSONObject publishTelegram(String title, String lead, String body, byte[] image, String imageName, String imageType) throws Exception {
        String token = secureStore.get("telegram_token");
        String channel = clean(prefs.getString("telegram_channel", ""));
        if (token.isEmpty() || channel.isEmpty()) throw new Exception("تلگرام هنوز تنظیم نشده است");
        String base = "https://api.telegram.org/bot" + token + "/";
        JSONObject first;
        if (image != null) {
            first = httpMultipart(base + "sendPhoto",
                    new String[][]{{"chat_id", channel}, {"caption", shortText(joinNonEmpty(title, lead), 1000)}},
                    "photo", safeFileName(imageName), imageType, image);
            ensureOk(first, "Telegram");
            if (!body.isEmpty()) sendChunkedJson(base + "sendMessage", channel, body, 3900, "Telegram");
        } else {
            String full = formatNews(title, lead, body);
            List<String> chunks = chunkText(full, 3900);
            first = null;
            for (String chunk : chunks) {
                JSONObject d = httpJson("POST", base + "sendMessage", new JSONObject().put("chat_id", channel).put("text", chunk));
                ensureOk(d, "Telegram");
                if (first == null) first = d;
            }
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("message", "ارسال به تلگرام موفق بود");
        out.put("messageId", extractMessageId(first));
        return out;
    }

    private JSONObject publishBale(String title, String lead, String body, byte[] image, String imageName, String imageType) throws Exception {
        String token = secureStore.get("bale_token");
        String channel = clean(prefs.getString("bale_channel", ""));
        if (token.isEmpty() || channel.isEmpty()) throw new Exception("بله هنوز تنظیم نشده است");
        String base = "https://tapi.bale.ai/bot" + token + "/";
        JSONObject first;
        if (image != null) {
            first = httpMultipart(base + "sendPhoto",
                    new String[][]{{"chat_id", channel}, {"caption", shortText(joinNonEmpty(title, lead), 3000)}},
                    "photo", safeFileName(imageName), imageType, image);
            ensureOk(first, "Bale");
            if (!body.isEmpty()) sendChunkedJson(base + "sendMessage", channel, body, 3900, "Bale");
        } else {
            String full = formatNews(title, lead, body);
            List<String> chunks = chunkText(full, 3900);
            first = null;
            for (String chunk : chunks) {
                JSONObject d = httpJson("POST", base + "sendMessage", new JSONObject().put("chat_id", channel).put("text", chunk));
                ensureOk(d, "Bale");
                if (first == null) first = d;
            }
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("message", "ارسال به بله موفق بود");
        out.put("messageId", extractMessageId(first));
        return out;
    }

    private JSONObject publishRubika(String title, String lead, String body, byte[] image, String imageName, String imageType) throws Exception {
        String token = secureStore.get("rubika_token");
        String chat = clean(prefs.getString("rubika_chat", ""));
        if (token.isEmpty() || chat.isEmpty()) throw new Exception("روبیکا هنوز تنظیم نشده است");
        String full = formatNews(title, lead, body);
        JSONObject sent;
        if (image != null) {
            JSONObject ticket = rubikaCall(token, "requestSendFile", new JSONObject().put("type", "Image"));
            ensureRubikaOk(ticket);
            String uploadUrl = unwrapString(ticket, "upload_url");
            if (uploadUrl.isEmpty()) throw new Exception("روبیکا آدرس آپلود برنگرداند");
            JSONObject uploaded = httpMultipart(uploadUrl, new String[][]{}, "file", safeFileName(imageName), imageType, image);
            String fileId = unwrapString(uploaded, "file_id");
            if (fileId.isEmpty()) throw new Exception("روبیکا شناسه فایل برنگرداند");
            String head = shortText(joinNonEmpty(title, lead), 1700);
            sent = rubikaCall(token, "sendFile", new JSONObject().put("chat_id", chat).put("file_id", fileId).put("text", head));
            ensureRubikaOk(sent);
            if (!body.isEmpty()) sendRubikaChunks(token, chat, body, 3500);
        } else {
            sent = null;
            for (String chunk : chunkText(full, 3500)) {
                JSONObject d = rubikaCall(token, "sendMessage", new JSONObject().put("chat_id", chat).put("text", chunk));
                ensureRubikaOk(d);
                if (sent == null) sent = d;
            }
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("message", "ارسال به روبیکا موفق بود");
        out.put("messageId", unwrapString(sent, "message_id"));
        return out;
    }

    private void sendChunkedJson(String url, String chatId, String text, int max, String service) throws Exception {
        for (String chunk : chunkText(text, max)) {
            JSONObject d = httpJson("POST", url, new JSONObject().put("chat_id", chatId).put("text", chunk));
            ensureOk(d, service);
        }
    }

    private void sendRubikaChunks(String token, String chatId, String text, int max) throws Exception {
        for (String chunk : chunkText(text, max)) {
            JSONObject d = rubikaCall(token, "sendMessage", new JSONObject().put("chat_id", chatId).put("text", chunk));
            ensureRubikaOk(d);
        }
    }

    private JSONObject rubikaCall(String token, String method, JSONObject payload) throws Exception {
        return httpJson("POST", "https://botapi.rubika.ir/v3/" + token + "/" + method, payload);
    }

    private JSONObject httpJson(String method, String url, JSONObject body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(45000);
        conn.setRequestProperty("Accept", "application/json");
        if (body != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
        }
        return readJsonResponse(conn);
    }

    private JSONObject httpMultipart(String url, String[][] fields, String fileField, String fileName, String mime, byte[] fileBytes) throws Exception {
        String boundary = "----NegahJavan" + System.currentTimeMillis();
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(25000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
            for (String[] pair : fields) {
                if (pair == null || pair.length < 2) continue;
                writeFormField(out, boundary, pair[0], pair[1]);
            }
            if (fileBytes != null && fileField != null) {
                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"" + fileField + "\"; filename=\"" + fileName + "\"\r\n");
                out.writeBytes("Content-Type: " + (mime == null ? "application/octet-stream" : mime) + "\r\n\r\n");
                out.write(fileBytes);
                out.writeBytes("\r\n");
            }
            out.writeBytes("--" + boundary + "--\r\n");
            out.flush();
        }
        return readJsonResponse(conn);
    }

    private void writeFormField(DataOutputStream out, String boundary, String name, String value) throws Exception {
        out.writeBytes("--" + boundary + "\r\n");
        out.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.writeBytes("\r\n");
    }

    private JSONObject readJsonResponse(HttpURLConnection conn) throws Exception {
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        String text = readAll(stream);
        JSONObject out;
        try {
            out = new JSONObject(text == null || text.isEmpty() ? "{}" : text);
        } catch (Exception e) {
            out = new JSONObject();
            out.put("raw", text == null ? "" : text);
        }
        out.put("httpStatus", code);
        if (code < 200 || code >= 400) {
            String msg = out.optString("description", out.optString("message", out.optString("raw", "HTTP " + code)));
            throw new Exception(msg.isEmpty() ? "HTTP " + code : msg);
        }
        return out;
    }

    private void ensureOk(JSONObject d, String service) throws Exception {
        if (d == null) throw new Exception(service + " پاسخ نامعتبر داد");
        if (d.has("ok") && !d.optBoolean("ok", true)) {
            throw new Exception(d.optString("description", d.optString("message", service + " error")));
        }
    }

    private void ensureRubikaOk(JSONObject d) throws Exception {
        if (d == null) throw new Exception("Rubika پاسخ نامعتبر داد");
        if ("ERROR".equalsIgnoreCase(d.optString("status")) || (d.has("ok") && !d.optBoolean("ok", true))) {
            throw new Exception(d.optString("status_det", d.optString("message", "Rubika error")));
        }
    }

    private String extractMessageId(JSONObject d) {
        if (d == null) return "";
        JSONObject r = d.optJSONObject("result");
        if (r != null) return String.valueOf(r.optLong("message_id", 0));
        return String.valueOf(d.optLong("message_id", 0));
    }

    private String unwrapString(JSONObject d, String key) {
        if (d == null) return "";
        JSONObject data = d.optJSONObject("data");
        if (data != null && data.has(key)) return String.valueOf(data.opt(key));
        JSONObject result = d.optJSONObject("result");
        if (result != null && result.has(key)) return String.valueOf(result.opt(key));
        if (d.has(key)) return String.valueOf(d.opt(key));
        return "";
    }

    private void shareToWhatsApp(String text) {
        runOnUiThread(() -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, text);
            try {
                share.setPackage("com.whatsapp");
                startActivity(share);
            } catch (ActivityNotFoundException e) {
                try {
                    share.setPackage("com.whatsapp.w4b");
                    startActivity(share);
                } catch (ActivityNotFoundException ex) {
                    share.setPackage(null);
                    startActivity(Intent.createChooser(share, "اشتراک‌گذاری خبر"));
                }
            }
        });
    }

    private String formatNews(String title, String lead, String body) {
        return joinNonEmpty(title, lead, body);
    }

    private String joinNonEmpty(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            String v = clean(p);
            if (v.isEmpty()) continue;
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(v);
        }
        return sb.toString();
    }

    private List<String> chunkText(String text, int max) {
        List<String> out = new ArrayList<>();
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return out;
        while (t.length() > max) {
            int cut = t.lastIndexOf('\n', max);
            if (cut < max / 2) cut = t.lastIndexOf(' ', max);
            if (cut < max / 2) cut = max;
            out.add(t.substring(0, cut).trim());
            t = t.substring(cut).trim();
        }
        if (!t.isEmpty()) out.add(t);
        return out;
    }

    private String shortText(String s, int max) {
        String v = s == null ? "" : s;
        return v.length() <= max ? v : v.substring(0, Math.max(0, max - 1)) + "…";
    }

    private String safeFileName(String name) {
        String n = clean(name);
        if (n.isEmpty()) n = "news.jpg";
        return n.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private String clean(String s) {
        return s == null ? "" : s.trim();
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private void callback(String functionName, String json) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String safe = JSONObject.quote(json);
            webView.evaluateJavascript("window.NJ && window.NJ." + functionName + " && window.NJ." + functionName + "(JSON.parse(" + safe + "));", null);
        });
    }

    private String jsonOk(String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("message", message);
            return o.toString();
        } catch (Exception e) {
            return "{\"ok\":true}";
        }
    }

    private String jsonError(String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("message", message == null ? "خطای ناشناخته" : message);
            return o.toString();
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private static class SecureStore {
        private static final String KEYSTORE = "AndroidKeyStore";
        private static final String ALIAS = "negah_javan_connector_key_v1";
        private final SharedPreferences prefs;

        SecureStore(SharedPreferences prefs) {
            this.prefs = prefs;
        }

        void put(String key, String value) throws Exception {
            SecretKey secretKey = getOrCreateKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] iv = cipher.getIV();
            byte[] enc = cipher.doFinal((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            ByteArrayOutputStream all = new ByteArrayOutputStream();
            all.write(iv.length);
            all.write(iv);
            all.write(enc);
            prefs.edit().putString("enc_" + key, Base64.encodeToString(all.toByteArray(), Base64.NO_WRAP)).apply();
        }

        String get(String key) {
            try {
                String raw = prefs.getString("enc_" + key, "");
                if (raw == null || raw.isEmpty()) return "";
                byte[] all = Base64.decode(raw, Base64.NO_WRAP);
                if (all.length < 14) return "";
                int ivLen = all[0] & 0xff;
                if (ivLen <= 0 || all.length <= 1 + ivLen) return "";
                byte[] iv = new byte[ivLen];
                byte[] enc = new byte[all.length - 1 - ivLen];
                System.arraycopy(all, 1, iv, 0, ivLen);
                System.arraycopy(all, 1 + ivLen, enc, 0, enc.length);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
                return new String(cipher.doFinal(enc), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "";
            }
        }

        private SecretKey getOrCreateKey() throws Exception {
            KeyStore ks = KeyStore.getInstance(KEYSTORE);
            ks.load(null);
            KeyStore.Entry entry = ks.getEntry(ALIAS, null);
            if (entry instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build());
            return kg.generateKey();
        }
    }
}
